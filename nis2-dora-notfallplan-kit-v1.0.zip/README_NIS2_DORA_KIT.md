# DACH Digitalwerk ? NIS-2 & DORA Notfallplan- & Lieferketten-Kit (v1.0)
Stand: November 2026 | Rechtsgrundlage: NIS-2-Umsetzungsgesetz (?? 28, 30, 32, 38 BSIG) & EU DORA (VO (EU) 2022/2554)

Enthaltene Vorlagen:
1. `01_BSI_24h_72h_Incident_Response_Runbook.md` ? Operativer Melde- und Eskalationsplan (24h Fr?hwarnung, 72h Vorfallmeldung, 30d Abschlussbericht)
2. `02_Lieferketten_Sicherheitsnachweis_B2B.md` ? Selbstauskunft & Sicherheitsgarantie f?r enterprise-Auftraggeber (? 30 Abs. 2 Nr. 4 BSIG)
3. `03_Web_Mail_Infrastructure_Hardening.md` ? Technische Pr?fliste (TLS 1.3, HSTS, CSP, SPF/DKIM/DMARC, MFA, Immutable Backups)

Support & Individuelles NIS-2/DORA-Technik-Audit:
E-Mail: dach.digitalwerk@gmail.com
Web: https://dachdigitalwerk.github.io/nis2-dora-compliance-generator/
