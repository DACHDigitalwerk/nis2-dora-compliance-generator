# Technische H?rtungs-Checkliste (Web, E-Mail & Cloud)
1. **E-Mail-Authentifizierung gegen CEO-Fraud & Spoofing:**
   - SPF (`v=spf1 ... -all`), DKIM (2048-Bit RSA) und DMARC (`v=DMARC1; p=quarantine; rua=...`) aktiv.
2. **HTTP Security Headers:**
   - `Strict-Transport-Security: max-age=63072000; includeSubDomains; preload`
   - `Content-Security-Policy`
   - `X-Content-Type-Options: nosniff`
   - `Referrer-Policy: strict-origin-when-cross-origin`
