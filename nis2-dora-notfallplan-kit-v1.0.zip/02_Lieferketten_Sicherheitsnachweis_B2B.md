# B2B-Sicherheitsnachweis f?r die Lieferkette (? 30 Abs. 2 Nr. 4 BSIG / NIS-2)

Hiermit best?tigt das unterzeichnende Unternehmen die Umsetzung folgender Mindestsicherheitsma?nahmen gem?? ? 30 BSIG / Art. 21 NIS-2-Richtlinie:
- [x] **Multi-Faktor-Authentifizierung (MFA):** Verpflichtend f?r alle privilegierten Konten, Remote-Zug?nge, E-Mail- und Cloud-Systeme.
- [x] **Backup- & Recovery-Konzept (3-2-1-1-0):** T?gliche verschl?sselte Backups inkl. mindestens einer unver?nderlichen (immutable/offline) Kopie.
- [x] **Schwachstellen- & Patch-Management:** Kritische Sicherheitsupdates (CVSS >= 9.0) werden innerhalb von 72 Stunden eingespielt.
- [x] **Verschl?sselung & Kryptografie:** Durchg?ngige Transportverschl?sselung (TLS 1.2/1.3, HSTS) sowie Ruhedatenverschl?sselung (AES-256).
- [x] **Incident-Response-Meldeweg:** Unverz?gliche Benachrichtigung betroffener B2B-Auftraggeber innerhalb von 24 Stunden bei sicherheitsrelevanten Vorf?llen mit Lieferkettenbezug.
