# Operatives Incident-Response-Runbook (? 30 Abs. 2 Nr. 2 & ? 32 BSIG / NIS-2)

## 1. Meldefristen bei erheblichen Sicherheitsvorf?llen (? 32 BSIG)
- **Stufe 1 ? Fr?hwarnung (innerhalb von max. 24 Stunden ab Kenntnisnahme):**
  - Erstmeldung an das BSI-Meldeportal: Verdacht auf rechtswidrige/b?swillige Handlung oder grenz?berschreitende Auswirkung.
- **Stufe 2 ? Qualifizierte Vorfallmeldung (innerhalb von max. 72 Stunden):**
  - Aktualisierung der Fr?hwarnung + erste Bewertung des Schweregrads, der Auswirkungen sowie Kompromittierungsindikatoren (IoCs).
- **Stufe 3 ? Abschlussbericht (sp?testens nach 1 Monat):**
  - Ausf?hrliche Beschreibung des Vorfalls, Ursachenanalyse (Root Cause), getroffene Abhilfema?nahmen.

## 2. Sofortma?nahmen (Erste 60 Minuten)
1. **Isolieren statt Ausschalten:** Betroffene Segmente vom Netzwerk trennen (RAM-Forensik erhalten, Systeme nicht unkontrolliert ?berschreiben).
2. **Zug?nge sperren & Tokens widerrufen:** Kompromittierte Service-Accounts, VPN-Zertifikate und OAuth-Sessions rotieren.
3. **Krisenstab aktivieren:** Gesch?ftsleitung (? 38 BSIG), IT-Sicherheitsbeauftragten und Datenschutzbeauftragten (Art. 33 DSGVO 72h-Frist pr?fen) informieren.
